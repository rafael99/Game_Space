<?php

	session_start();
	include "conexao/conecta.php";
	
	$id_user = $_POST['id_user'];
	$nick = $_POST['nick'];
	
	$nome = $_POST['nome'];
	$data_nasc = $_POST['ano']."-".$_POST['mes']."-".$_POST['dia'];
	$telefone = $_POST['telefone'];
	$email = $_POST['email'];
	$sexo = $_POST['sexo'];
	$skype = $_POST['skype'];
	$raidcall = $_POST['raidcall'];
	$teamspeak = $_POST['teamspeak'];
	$facebook = $_POST['facebook'];

	if($_FILES["foto"]["error"] == 0){
		$foto = sha1(time(). $_FILES["foto"]["name"]).".".
		substr($_FILES["foto"]["name"], strpos(strrev($_FILES["foto"]["name"]), ".")*-1);
		move_uploaded_file($_FILES["foto"]["tmp_name"], "imagens_user/".$foto);
		
		$_SESSION['foto'] = $foto;
		if(isset($_COOKIE['nick']) ){
		setcookie("foto", $foto, time() + (86400*2));
		}
	}else{
		$foto = -1;
	}
	
	if($con){
		$sql2 = "select * from usuario where id_user = ".$_POST['id_user'];
		$rs2 = mysqli_query($con, $sql2);
			if($rs2){
				$valor = mysqli_fetch_array($rs2);
				if($valor["foto"] != "nouser.png" && $valor["foto"] != $valor["foto"]){
					unlink("imagens_user/".$valor["foto"]);
				}
			}
	}

	if($con){
		$sql = "update usuario set
				nick = '$nick',
				nome = '$nome',
				data_nasc = '$data_nasc',
				telefone = '$telefone',
				email = '$email',
				sexo = '$sexo',
				skype = '$skype',
				raidcall = '$raidcall',
				teamspeak = '$teamspeak',
				facebook = '$facebook'".($foto == -1 ? "": ", foto = '$foto' ")."
			where id_user = $id_user";
		$rs = mysqli_query($con, $sql);
		$_SESSION['nick'] = $nick;
		
		if(isset($_COOKIE['nick']) ){
			setcookie("nick", $nick, time() + (86400*2));
		}
	
		if($rs){
			echo"<meta http-equiv='refresh' content='0;url=index.php'>";
		}else{
			echo " Erro de alteração: ".mysqli_error($con);
		}
	}else{
		echo " Erro de conexão: ".mysqli_error($con);
	}
	mysqli_close($con);
?>