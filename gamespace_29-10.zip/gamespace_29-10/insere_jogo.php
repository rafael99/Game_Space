<?php
	include "template/topo.php";
	
	$distribuidora_jogo = $_POST['distribuidora_jogo'];
	$plataforma_jogo = $_POST['plataforma_jogo'];
	$descricao_jogo = $_POST['descricao_jogo'];
	$genero_jogo = $_POST['genero_jogo'];
	$nome_jogo = $_POST['nome_jogo'];
	
	if ($_FILES["foto"]["error"] == 0){
		$ext = substr($_FILES["foto"]["name"],
			strpos(strrev($_FILES["foto"]["name"]), ".") *-1);
		
		$foto = sha1(time().$_FILES["foto"]["name"]).".".$ext;
		move_uploaded_file($_FILES["foto"]["tmp_name"], "imagens_jogo/".$foto);
	}else{
		$foto = "noimage.png";
	}

	if($con){
		$sql = "insert into jogo(distribuidora_jogo, plataforma_jogo, descricao_jogo, genero_jogo, nome_jogo,foto)".
			" values('$distribuidora_jogo', '$plataforma_jogo', '$descricao_jogo', '$genero_jogo', '$nome_jogo', '$foto')";
		$rs = mysqli_query($con, $sql);
		if($rs){
			echo "<h1> Jogo cadastrado com sucesso. </h1>";
			echo"<meta http-equiv='refresh' content='1;url=admin.php'>";
		}else{
			echo " Erro de inclusão: ".mysqli_error();
		}
	}else{
		echo " Erro de conexão: ".mysqli_error();
	}
	include "template/footer.php";
?> 
