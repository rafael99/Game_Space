<?php
session_start();


		session_destroy(); 
		
			setcookie("nick", "", time());
			setcookie("senha", "", time());
			setcookie("nome", "", time());
			setcookie("tipo", "", time());
			setcookie("id_user","", time());
			setcookie("foto", "", time());
			
			echo"<meta http-equiv='refresh' content='0;url=index.php'>";
		

		

?> 