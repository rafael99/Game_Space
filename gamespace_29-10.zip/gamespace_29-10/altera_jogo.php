<?php
	include"template/topo.php";
	if(!isset($_SESSION['nick']) ){
    	if(!isset($_COOKIE['nick'])){
        	echo"<meta http-equiv='refresh' content='0;url=index.php'>";
    	}
	    else{
			
	        $sql = "select * from usuario where nick = ".$_COOKIE['nick'];
	        $rs=mysqli_query($con, $sql);
	        $_SESSION["nick"] = $_COOKIE['nick'];
	        $_SESSION["senha"] =$_COOKIE['nick'];
	        $_SESSION["nome"] = $_COOKIE['nick'];
	    }
	}

	else if($_SESSION["tipo"] == 1){
	    echo"<meta http-equiv='refresh' content='0;url=index.php'>";
	}
	if($con){
		$sql = "select * from jogo WHERE id_jogo=".$_GET['id'];
		$rs = mysqli_query($con, $sql);
		if($rs){
			if($valor = mysqli_fetch_array($rs)){ 
			
?>
<div id="content" >
	<form name="incCliente" action="update_jogo.php" method="POST" enctype="multipart/form-data"> 
					<div class="box"> 

						<h1 style="margin-left: 100px; color: #173356; font-family: arial;"  >ALTERA JOGO</h1> 
						<input type ="hidden" name="id_jogo" value="<?php echo $valor['id_jogo'];?>">
						<label> 
							<span>Nome:</span>
							<input type="text" class="input_text" name="nome_jogo" maxlength="30"
							value = "<?php echo $valor['nome_jogo'];?>"							> 
						</label>
						<label> 
							<span>Distribuidora:</span>
							<input type="text" class="input_text" name="distribuidora_jogo" maxlength="30" 
							value = "<?php echo $valor['distribuidora_jogo'];?>"> 
						</label>
						<label> 
							<span>Plataforma:</span>
							<input type="text" class="input_text" name="plataforma_jogo" maxlength="50" 
							value = "<?php echo $valor['plataforma_jogo'];?>"> 
						</label>
						<label> 
							<span>Gênero:</span>
							<input type="text" class="input_text" name="genero_jogo" maxlength="30" 
							value = "<?php echo $valor['genero_jogo'];?>"> 
						</label>
						<label> 
							<span>Descrição:</span>
							<textarea type="text" class="input_text2" name="descricao_jogo" cols="40" rows="10">
							<?php echo $valor['descricao_jogo'];?></textarea>
						</label>
						<label> 
							<span>Foto:</span>
							<img src = 'imagens_jogo/<?php echo $valor['foto'] ?>' alt = 'imagens/noimage.png' height = '70'>
						</label>

                                                <label>
                                                <input type = "file"  name = "foto" id = "id_jogo" class = "altera_img_jogo" >
                                                </label>

                        <label>
						<input type="submit" class="button_alterar" value="ALTERAR" >
						<p class="button_admin"><a href="admin.php">ADMIN/VOLTAR</a></p>
						<br><br><br><br>
						<a href="delete_jogo.php?id=<?php echo$valor["id_jogo"]?>"><p class="deletar">DELETAR</p></a>
						</label>
						
	</form>
						
						
						
					       
						
</div>				
<?php }
			else{echo "Jogo não encontrado";}
			mysqli_free_result($rs);
		}else{echo "Erro de alteração de Jogo: ".mysqli_error($con);}
	}
	else{ echo "Erro de conexão: ".mysqli_error($con); }
	include"template/footer.php";
?>