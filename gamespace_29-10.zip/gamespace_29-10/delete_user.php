<?php
	include "template/topo.php";
	$id_user = $_GET['id'];
	if($con){
		$sql = "select * from usuario where id_user = ".$_GET['id'];
		$rs = mysqli_query($con, $sql);
		if($rs){
			if($valor = mysqli_fetch_array($rs)){
				$sql = "delete from usuario where id_user = $id_user;";
			$rs = mysqli_query($con, $sql);
			if($rs){
				echo "<h1>Cadastro excluido com sucesso.</h1>";
				if($valor["foto"] != "nouser.png"){
					unlink("imagens_user/".$valor["foto"]);
				}
			}
			}
		}else{
			echo " Erro de exclusão: ".mysqli_error($con);
		}
	}else{
		echo " Erro de conexão: ".mysqli_error($con);
	}
	include "template/footer.php";
?>