$("#foto").change(function() {
    $(this).prev().html($(this).val());
});