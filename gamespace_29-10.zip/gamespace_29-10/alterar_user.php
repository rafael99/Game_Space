<?php
	include "template/topo.php";

	if($con){
		$sql = "select * from usuario WHERE id_user=".$_SESSION['id_user'];
		$rs = mysqli_query($con, $sql);
		if($rs){
			if($valor = mysqli_fetch_array($rs)){ ?>
           
<div id="content">
                <div id="altera_user">
                    
                    <form name = "altUser" action = "update_user.php" method = "POST" enctype="multipart/form-data">
					<h1 class="titulo_perfil" align="center"> ALTERAR PERFIL </h1>
                <div id="dados_perfil">
                	<h4 class="dados">Dados do Pefil</h4>
					<input type = "hidden" name = "id_user" size = 5 
						value = "<?php echo $valor['id_user'];?>" readonly><br>
                    <label>
					<span>Foto:</span> <img src = 'imagens_user/<?php echo $valor['foto'] ?>' alt = 'imagens_user/nouser.png' height = '70'>
						<input type = "file" name = "foto" id = "foto">
                    </label>
                    <br>
                    <label>
					<span>Nick*:</span> 
                        <input type = "text" required  class="campos_texto" name = "nick" size = "40" maxlength = "80"
						value = "<?php echo $_SESSION['nick'];?>" >
                    </label>
                    <br>
                </div>

                <div id="dados_pessoais">
                	<h4 class="dados">Dados Pessoais</h4>
                    <label>
					<span>Nome:</span> <input type = "text" class="campos_texto"  name = "nome"  class="input_text" size = "40" maxlength = "80"
						value = "<?php echo $valor['nome'];?>" >
                    </label>
                    <br>
                    <label>
					<span>Data de Nascimento:</span>
							<?PHP $dia = substr($valor['data_nasc'], 8,2);
							$mes = substr($valor['data_nasc'], 5, 2);
							$ano = substr($valor['data_nasc'], 0,4 ); ?>
							<input type="text"  class="campos_texto" class="input_textd"  name="dia" size="2" maxlength="2" placeholder="dd" value = "<?php echo $dia;?>" > 
						   <input type="text"  class="campos_texto" class="input_textd" name="mes" size="2" maxlength="2" placeholder="mm" value = "<?php echo $mes;?>" > 
						   <input type="text" class="campos_texto" class="input_textd" name="ano" size="4" maxlength="4" placeholder="aaaa" value = "<?php echo $ano;?>" >
                    </label>
                    <br>
                    <label>
					<span>Telefone:</span> <input type = "text" class="campos_texto" name = "telefone" class="input_text" size = "40" maxlength = "20"
						value = "<?php echo $valor['telefone'];?>" >
                    </label>
                    <br>
                    <label>
					<span>E-mail*:</span> <input type = "email" required class="campos_texto" name = "email" size = "40" maxlength = "150"
						value = "<?php echo $valor['email'];?>" >
                    </label><br>
                    <label>		<!-- value = "n" singnifica nullo -->
					<span>Sexo:</span><span> <input checked type = "radio" name="sexo" value="n"> Nulo
							<input  type = "radio" name = "sexo" value = "M"
						<?php echo $valor['sexo'] == "M"?"checked":"";?>> Masculino
							<input  type = "radio" name = "sexo" value = "F"
                                  		 <?php echo $valor['sexo'] == "F"?"checked":"";?>> Feminino </span>
                    
                    </label>
                    </div>
                    <div id="redes_sociais">
                    	<h4 class="dados">Redes Sociais</h4>
	                    <label>
						<span>Skype:</span> <input type = "text" class="campos_texto" name = "skype" size = "40" maxlength = "50"
						value = "<?php echo $valor['skype'];?>" >
	                    </label>
	                    <label>
						<span>Raidcall:</span> <input type = "text" class="campos_texto" name = "raidcall" size = "40" maxlength = "50"
						value = "<?php echo $valor['raidcall'];?>" >
	                    </label>
	                    <label>
						<span>Teamspeak:</span> <input type = "text" class="campos_texto" name = "teamspeak" size = "40" maxlength = "50"
						value = "<?php echo $valor['teamspeak'];?>" >
	                    </label>
	                    <label>
						<span>Facebook:</span> <input type = "text"  class="campos_texto" name = "facebook" size = "40" maxlength = "50"
						value = "<?php echo $valor['facebook'];?>" >
	                    </label>
                    </div>
                       <br>
                    <h3 class="obrigatorio" align="center">* Campos Obrigatórios</h3>
                    <center><label>
                        <input type="submit" class="button_altera_perfil" value="ALTERAR">
                    </label></center>
				</form>
                
    </div>
</div>

			<?php }
			else{echo "Usuário não cadastrado";}
			mysqli_free_result($rs);
		}else{echo "Erro de alteração de usuário: ".mysqli_error($con);}
	}
	else{ echo "Erro de conexão: ".mysqli_error($con); }
	include "template/footer.php";
?>