<?php
	include "template/topo.php";
	$id_jogo = $_POST['id_jogo'];
	$distribuidora_jogo = $_POST['distribuidora_jogo'];
	$plataforma_jogo = $_POST['plataforma_jogo'];
	$descricao_jogo = $_POST['descricao_jogo'];
	$genero_jogo = $_POST['genero_jogo'];
	$nome_jogo = $_POST['nome_jogo'];


	if($_FILES["foto"]["error"] == 0){
		$foto = sha1(time(). $_FILES["foto"]["name"]).".".
		substr($_FILES["foto"]["name"], strpos(strrev($_FILES["foto"]["name"]), ".")*-1);
		move_uploaded_file($_FILES["foto"]["tmp_name"], "imagens_jogo/".$foto);
	}else{
		$foto = -1;
	}
	
	if($con){
		$sql = "select * from jogo where id_jogo = ".$_POST['id_jogo'];
		$rs = mysqli_query($con, $sql);
			if($rs){
				$valor = mysqli_fetch_array($rs);
				if($valor["foto"] != "noimage.png" && $valor["foto"] != $valor["foto"]){
					unlink("imagens_jogo/".$valor["foto"]);
				}
			}
	}

	if($con){
		$sql = "update jogo set
				distribuidora_jogo = '$distribuidora_jogo',
				plataforma_jogo = '$plataforma_jogo',
				descricao_jogo = '$descricao_jogo',
				genero_jogo = '$genero_jogo',
				nome_jogo = '$nome_jogo'".($foto == -1 ? "": ", foto = '$foto' ")."
			where id_jogo = $id_jogo";
		$rs = mysqli_query($con, $sql);
		if($rs){
			echo "<h1> Jogo atualizado com sucesso. </h1>";
			echo"<meta http-equiv='refresh' content='1;url=admin.php'>";
		}else{
			echo " Erro de alteração: ".mysqli_error($con);
		}
	}else{
		echo " Erro de conexão: ".mysqli_error($con);
	}
	include "template/footer.php";
?>

