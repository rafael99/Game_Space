-- phpMyAdmin SQL Dump
-- version 4.0.10.14
-- http://www.phpmyadmin.net
--
-- Servidor: localhost:3306
-- Tempo de Geração: 30/10/2016 às 03:24
-- Versão do servidor: 5.6.30
-- Versão do PHP: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de dados: `admgasp_gamespace`
--
CREATE DATABASE IF NOT EXISTS `admgasp_gamespace` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `admgasp_gamespace`;

-- --------------------------------------------------------

--
-- Estrutura para tabela `jogo`
--

DROP TABLE IF EXISTS `jogo`;
CREATE TABLE IF NOT EXISTS `jogo` (
  `distribuidora_jogo` varchar(27) NOT NULL,
  `plataforma_jogo` varchar(50) DEFAULT NULL,
  `descricao_jogo` varchar(600) DEFAULT NULL,
  `genero_jogo` varchar(20) NOT NULL,
  `nome_jogo` varchar(150) NOT NULL,
  `id_jogo` int(11) NOT NULL AUTO_INCREMENT,
  `foto` varchar(50) NOT NULL,
  PRIMARY KEY (`id_jogo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Fazendo dump de dados para tabela `jogo`
--

INSERT INTO `jogo` (`distribuidora_jogo`, `plataforma_jogo`, `descricao_jogo`, `genero_jogo`, `nome_jogo`, `id_jogo`, `foto`) VALUES
('Critical Force Ltd.', 'Browser / Mobile', '																																																	Critical Ops Ã© um jogo de tiro em primeira pessoa que vai testar seus reflexos e habilidade tÃ¡tica. Vivencie a emoÃ§Ã£o de combater o terrorismo como um contraterrorista ou cause destruiÃ§Ã£o como um terrorista. Lute ao lado de seus amigos, ou mostre ao mundo sua habilidade individual.', 'FPS', 'Critical Ops', 2, 'c5b391ef9f0aace40f7b4f17b4b1f823697cdafb.png'),
('Level Up', 'PC', '																																																																						Elsword Ã© um jogo de aÃ§Ã£o que mistura elementos dos clÃ¡ssicos jogos de plataforma com os de jogos de luta, num mundo de fantasia medieval no qual vocÃª pode controlar diferentes herÃ³is em sua batalha contra as forÃ§as do mal.\r\n\r\nÃ‰ um jogo fÃ¡cil de aprender e divertido de se jogar! Em pouco tempo vocÃª terÃ¡ dominado os comandos bÃ¡sicos do seu personagem, e entÃ£o bastarÃ¡ criar sua estratÃ©gia e acabar com os inimigos!\r\n\r\nCom mecÃ¢nicas de jogo dinÃ¢micas e fÃ¡ceis de entender, nÃ£o leva muito tempo para se acostumar', 'RPG', 'Elsword', 3, '0777e59dfb2fbe53c0417ff5faafcf6cf233c8b3.png'),
('Level Up', 'PC/Moblie', '																																										RagnarÃ¶k foi o primeiro jogo de MMORPG lanÃ§ado pela Level Up! no Brasil. Mas vocÃª sabe o que Ã© MMORPG? EntÃ£o vamos por partes.\r\nMMO Ã© uma sigla que significa Massive Multi-player Online (multiplayer online massivo) e tem esse nome por trazer um mundo aberto com enorme capacidade de jogadores que podem jogar online simultaneamente - daÃ­ o termo "mas-sivo" - em que todos podem interagir entre si.', 'RPG', 'RagnarÃ¶k Online', 4, '7d1a3d979c0d5d7916f400d7af0ff1e0a7935357.png'),
(' Digital Extremes', 'PC/Xbox/Playstati', '																																			\r\nHISTÃ“RIA\r\n\r\nEles foram chamados Tenno. Guerreiros da lÃ¢mina e arma: mestres da armadura Warframe. Aqueles que sobreviveram Ã  guerra de idade foram deixados Ã  deriva entre as ruÃ­nas. Agora eles sÃ£o necessÃ¡rios mais uma vez.\r\n\r\nO Grineer, com seus vastos exÃ©rcitos, estÃ£o se espalhando por todo o sistema solar. Uma chamada ecoa atravÃ©s das estrelas de invocaÃ§Ã£o do Tenno para um lugar antigo. Eles chamar-te.\r\n\r\nPermitir que a Lotus para guiÃ¡-lo. Ela salvou-se da sua cÃ¢mara de Cryostasis e lhe deu uma chance de sobreviver. O Grineer vai encontrÃ¡-l', 'TPS', 'Warframe', 6, '489cce0e55081c19a412cf6933fb547eb2dd8e47.png'),
('ongame', 'PC', '																												Point Blank Ã© um jogo free-to-play de tiro em primeira pessoa on-line, no formato Massively Multiplayer Online Game. Sua produtora Ã© a Zepetto, uma desenvolvedora de jogos coreana. No Brasil, a editora responsÃ¡vel pelo jogo Ã© a Ongame.', 'FPS', 'Point Blank', 7, '7375ce0a5a27f5e4fe199e0d7d094a6be18efdca.png'),
('XCloudGame', 'Browser', '																					BloodStrike foi o primeiro jogo de tiro em primeira pessoa que lhe proporciona, um combate direto e com belos efeitos visuais no estilo tiroteio, basta abrir uma pÃ¡gina na web para a diversÃ£o comeÃ§ar. Uma variedade de modos de batalhas para alcanÃ§ar o Ã¡pice...', 'FPS', 'Blood Strike', 8, 'a281469e44aa4a4e3d42233f9793b75cbe013c2d.png'),
('Z8Games', 'dasdasdas', '																																																								CrossFire Ã© um jogo de FPS online publicado pelo grupo sul-coreano NEOWIZ. O jogo foi lanÃ§ado na China pela empresa Tencent, e a mesma opera o jogo pela internet, em domÃ­nios chineses suportados pelas empresas China Telecom e China Netcom. No fim de 2011 o jogo foi lanÃ§ado para o Brasil.', 'FPS', 'CrossFire', 9, '2261455f0bcc6f30e02d5a3f1a2b0e85362a8225.png'),
('Crytek', 'PC/ Xbox 360 / PlayStation 3', '																																																																							Warface Ã© um jogo eletrÃ´nico on-line free-to-play (gratuito para jogar) de tiro em primeira pessoa desenvolvido pela Crytek e distribuÃ­do no Brasil pela Level Up! Games.', 'FPS', 'Warface', 10, '2452c4ac844b82bf85be89c4f21d70d6ddb236c5.png'),
('Sony Online Entertainment', 'PlayStation 4 / Xbox One / Play Station 3 / PC', '																																			DC Universe Online ou DCUO Ã© um jogo de MMO desenvolvido pela Sony Online para PlayStation 3, Playstation 4 e Computador pessoal, baseado na sÃ©rie de superherÃ³is DC Comics.', 'MMORPG', 'DC Universe Online', 11, '253f2d2a577d3db12b300cc82e628cdc296f3ded.jpg'),
('Valve', 'PC /  Xbox 360 / PlayStation 3', '																																			Counter-Strike: Global Offensive (CS:GO) Ã© um jogo de tiro em primeira pessoa online desenvolvido pela Valve Corporation e pela Hidden Path Entertainment, sendo uma sequÃªncia de Counter-Strike: Source. Ã‰ o quarto tÃ­tulo principal da franquia.', 'FPS', 'Counter-Strike: Global Offensive', 14, '0caf811f1d08677247ac22da5b3f21e45d8a0de5.png');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE IF NOT EXISTS `usuario` (
  `senha` varchar(50) NOT NULL,
  `nome` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(150) NOT NULL,
  `telefone` varchar(15) DEFAULT NULL,
  `data_nasc` date DEFAULT NULL,
  `tipo` char(1) DEFAULT '1',
  `status_user` varchar(8) NOT NULL,
  `sexo` char(1) NOT NULL,
  `skype` varchar(50) DEFAULT NULL,
  `raidcall` varchar(50) DEFAULT NULL,
  `facebook` varchar(50) DEFAULT NULL,
  `teamspeak` varchar(50) DEFAULT NULL,
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `nick` varchar(50) NOT NULL,
  `foto` varchar(50) NOT NULL,
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `nick` (`nick`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=569 ;

--
-- Fazendo dump de dados para tabela `usuario`
--

INSERT INTO `usuario` (`senha`, `nome`, `email`, `telefone`, `data_nasc`, `tipo`, `status_user`, `sexo`, `skype`, `raidcall`, `facebook`, `teamspeak`, `id_user`, `nick`, `foto`) VALUES
('12dea96fec20593566ab75692c9949596833adc9', 'UsuÃ¡rio de Guia AnÃ´nima', 'user@gasp.com', '40028922', '1996-06-06', '1', '', 'M', '', '', '', '', 567, 'user', '0077b20b6adcc52290d239be101e1465d247769b.jpg'),
('8bcff93688db5a2a47b7e15b39164091a8dd670f', 'NÃ³iz Mesmo', 'adm@gasp.com', '60706070', '2001-09-11', '0', '', 'F', '', '', '', '', 568, 'admgasp', '5ee90e3020085e9ca3ef9639e6bae9d0a4d330c3.jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
