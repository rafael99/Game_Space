<?php
  include "conexao/conecta.php";
?>

<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>LOGIN - CADASTRO</title>
    <link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/normalize.css">    
    <link rel="stylesheet" href="css/style_login.css">
    
  <?php 
    
  ?>

  </head>
  <body>
    <br><br><br>
    <div class="form">
      
        <div id="signup">   <!--cadastro-->
          <h1>Criar uma conta Gamespace</h1>
          
          <form name = "incUser" action = "insere_user.php" method = "Post" enctype = "multipart/form-data">
          
          <div class="top-row">
        
            <div class="field-wrap">
              <label>
                Nick
              </label>
              <input type="text" class = "nick" name="nick"required autocomplete="off"/>
            </div>
          </div>

          <div class="field-wrap">
            <label>
              Email
            </label>
            <input type="email" name = "email" required autocomplete="off"/>
          </div>
          
          <div class="field-wrap">
            <label>
              Senha
            </label>
            <input type="password" name = "senha" required autocomplete="off"/>
          </div>
          <input type = "file" name= "foto">
          <spam name="img_perfil" class = "nome_foto">Foto de Perfil</spam>

          <button type="submit" class="button button-block">CADASTRAR</button>
          
          </form>

        </div> 
         <br>
        <a href="index.php" class = "voltar" >← VOLTAR</a>
        <a href="login.php" class = "voltar_login" >LOGIN</a>
    </div> <!-- /form -->
        <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
        <script src="js/index_login.js"></script>

    
  </body>

  <?php
    mysqli_close($con);
  ?>
</html>