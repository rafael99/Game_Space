<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
   
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style type="text/css">
   /* ------------------------------------------
  FIXED HEADER
--------------------------------------------- */

header {
  background: #161D30;
  position: fixed;
  z-index: 3;
  width: 100%;
  left: 0;
  top: 0;
}
/* ------------------------------------------
  RESPONSIVE NAV STYLES
--------------------------------------------- */

.nav-collapse ul {
  margin: 0;
  padding: 0;
  width: 100%;
  display: block;
  list-style: none;
}

.nav-collapse li {
  width: 100%;
  display: block;
}

.js .nav-collapse {
  clip: rect(0 0 0 0);
  max-height: 0;
  position: absolute;
  display: block;
  overflow: hidden;
  zoom: 1;
}

.nav-collapse.opened {
  max-height: 9999px;
}

.disable-pointer-events {
  pointer-events: none !important;
}

.nav-toggle {
  -webkit-tap-highlight-color: rgba(0,0,0,0);
  -webkit-touch-callout: none;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  -o-user-select: none;
  user-select: none;
}

@media screen and (min-width: 40em) {
  .js .nav-collapse {
    position: relative;
  }
  .js .nav-collapse.closed {
    max-height: none;
  }
  .nav-toggle {
    display: none;
  }
}


/* ------------------------------------------
  NOMES DOS MENUS
--------------------------------------------- */
.material-icons {
 float: left;
 margin-right: 5px;
 margin-top: -4px;
color:white;
}

.fixed {
  position: fixed;
  width: 100%;
  left: 0;
  top: 0;
}

.nav-collapse,
.nav-collapse * {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
}

.nav-collapse,
.nav-collapse ul {
  list-style: none;
  width: 100%;
  float: left;
}

@media screen and (min-width: 80em) {
  .nav-collapse {
    float: left;
    width: auto;
    margin-left: 500px;
  }
}

.nav-collapse li {
  float: left;
  width: 100%;
}

@media screen and (min-width: 40em) {
  .nav-collapse li {
    width: auto;
  }
}

.nav-collapse a {

  text-decoration: none;
  background: #161D30;
  padding: 1.5em 1em;
  color: #fff;
  width: 100%;
  float: left; 
  height: 64px;
  font-family: arial;
}


.nav-collapse a:hover {
  background:  #173356 ;

}

@media screen and (min-width: 40em) {
  .nav-collapse a {
    padding: 1.50em 2em;
    text-align: center;
    border-top: 0;
    float: left;
    margin: 0;
  }
}

.nav-collapse ul ul a {
  background: #ca3716;
  padding-left: 2em;
}

@media screen and (min-width: 40em) {
  .nav-collapse ul ul a {
    display: none;
  }
}


/* ------------------------------------------
  NAV TOGGLE STYLES
--------------------------------------------- */

@font-face {
  font-family: "responsivenav";
  src:url("../icons/responsivenav.eot");
  src:url("../icons/responsivenav.eot?#iefix") format("embedded-opentype"),
    url("../icons/responsivenav.ttf") format("truetype"),
    url("../icons/responsivenav.woff") format("woff"),
    url("../icons/responsivenav.svg#responsivenav") format("svg");
  font-weight: normal;
  font-style: normal;
}

.nav-toggle {
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-decoration: none;
  text-indent: -300px;
  position: relative;
  overflow: hidden;
  width: 100px;
  height: 55px;
  float: right;
}

.nav-toggle:before {
  color: #fff; /* Edit this to change the icon color */
  font: normal 28px/55px "responsivenav"; /* Edit font-size (28px) to change the icon size */
  text-transform: none;
  text-align: center;
  position: absolute;
  content: "\2261"; /* Hamburger icon */
  text-indent: 0;
  speak: none;
  width: 100%;
  left: 0;
  top: 0;
}

.nav-toggle.active:before {
  font-size: 24px;
  content: "\78"; /* Close icon */
}


.logo {
width:200px;
height: 60px;
margin-left: 10px;
margin-top: 3px;
text-decoration: none;
font-weight: bold;
line-height: 40px;
color: #fff;
float: left;
}
    </style>
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <link rel="stylesheet" href="css/ie.css">
    <![endif]-->
    
  </head>
  <body class = "body_deslog" >

    <header>
	<a href="index.php"><img src="imagens/spacelogo03.png" class="logo" data-scroll></a>
      <nav class="nav-collapse">
        <ul>
          <li class="menu-item active"><a href="index.php" data-scroll>HOME</a></li>
          <li class="menu-item"><a href="jogos.php" data-scroll>JOGOS</a></li>
          <li class="menu-item"><a href="#projects" data-scroll>SOBRE</a></li>
          <li class="menu-item"><a href="login.php" data-scroll>ENTRAR</a></li>
    
          
        </ul>
      </nav>
    </header>

    <script src="js/fastclick.js"></script>
    <script src="js/scroll.js"></script>
    <script src="js/fixed-responsive-nav.js"></script>
	<script src="js/responsive-nav.js"></script>
  </body>
</html>
