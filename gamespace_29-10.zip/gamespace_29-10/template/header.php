<?php
	if(isset($_COOKIE['nick']) ){
	$_SESSION['nick'] = $_COOKIE['nick'];
	$_SESSION['senha'] = $_COOKIE['senha'];
	$_SESSION["tipo"] = $_COOKIE['tipo'];
	//$_SESSION['nome'] = $_COOKIE['nome'];
	$_SESSION['id_user'] = $_COOKIE['id_user'];
	$_SESSION['foto'] = $_COOKIE['foto'];
}

?>
<html>
	<head>
		<title>GameSpace</title>
		<meta charset="utf-8">
		<!-- ICO -->
		
		<link rel="icon" href="imagens/icon.ico" type="image/ico" sizes="16x16">

		<!-- MINI PERFIL -->
		
		<link href='http://fonts.googleapis.com/css?family=Changa+One' rel='stylesheet' type='text/css'>

		<link rel='stylesheet prefetch' href='https://s3-us-west-2.amazonaws.com/s.cdpn.io/163697/normalize.css'>


		<link href='http://fonts.googleapis.com/css?family=Changa+One' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="css/search.css">

		<link rel="stylesheet" href="css/normalize_slide.css">
		<link rel="stylesheet" type="text/css" href="css/style_slide.css">

		<script type="script.js"></script>
 		<script src="http://s.codepen.io/assets/libs/modernizr.js" type="text/javascript"></script>
    	<script src="js/prefixfree.min.js"></script>

    	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	    <link rel="stylesheet" href="css/normalize.css">
		<link rel='stylesheet prefetch' href='https://cdn.rawgit.com/twbs/bootstrap/v4-dev/dist/css/bootstrap.css'>
	    <link rel="stylesheet"  href="css/css_mini_perfil.css">


	   <!--  NAV SEM ESTAR LOGADO -->
<meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="css/nav_deslogado.css">
 
	
	</head>
	<body>

		<div id="wrapper">	
			<!-- div id="login">

				<?php if(isset($_SESSION['nick']) ){
					include"conexao/conecta.php";
					$sql = "select * from usuario where nick = ".$_SESSION['nick'];
					$rs=mysqli_query($con, $sql); ?>
				<div id = "mini_perfil" >
				<img src="imagens_user/<?php echo $_SESSION['foto']?>" alt = "imagens_user/nouser.png"
				class="fotoperfil"><strong><p class="nomeperfil"><?php echo$_SESSION['nick'] ?></p></strong>
				<strong><select class = "oque_estou_jogando" style="color: #000;">
				
					<option selected class="fodase">JOGANDO</option>
					<option>Elsword</option>
					<option>WarFace</option>
					<option>Ragnarrok</option>
					<option>CODM3</option>
					<option>CsGO</option>
				</strong>
				</select>
				</div>

				<div class="container_logado">
			        
			        <div id="navigation-bar" class="clearfix">
			            
			            <form id="search" action="#" method="post">
			                <div id="label"><label for="search-terms" id="search-label">search</label></div>
			                <div id="input"><input type="text" name="search-terms" id="search-terms" placeholder="Enter para pesquisar..."></div>
			            </form>
			        </div>

			    </div>

				<?php
						}else{
						
				?>

				<form class="formulario2" name="form_login" action="logar.php" method="POST" >
					<input class="formulario" name="nick" placeholder="Nick" type="text"> 
					<input class="formulario" name="senha" placeholder="Senha" type="password">
					<input type="submit" class="envio" name="Entrar" value= "Entrar">
				</form>
							<div class="container_deslogado">
			        
			        <div id="navigation-bar" class="clearfix">
			            
			            <form id="search" action="#" method="post">
			                <div id="label"><label for="search-terms" id="search-label">search</label></div>
			                <div id="input"><input type="text" name="search-terms" id="search-terms" placeholder="Enter para pesquisar..."></div>
			            </form>
			        </div>

			    	</div --> 
				<?php

					}?>
			</div>
			<!-- mini perfil-->

			<script src="js/classie.js"></script>
			<script src="js/search.js"></script>

		<script src='https://code.jquery.com/jquery-2.2.4.min.js'></script>
		<script src='https://cdn.rawgit.com/twbs/bootstrap/v4-dev/dist/js/bootstrap.js'></script>
	