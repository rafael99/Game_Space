<?php
session_start();


	include"header.php";
	include"nav.php";
	include "conexao/conecta.php";

?>