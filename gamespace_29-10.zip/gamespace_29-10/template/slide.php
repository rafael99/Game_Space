<!-- ABRINDO SLIDE -->
			<div id="slider" >
				
				<div class="carousel">
		    <div class="inner">
		      <div class="slide active">
		      	<a href="#"></a>
		      </div>
		      <div class="slide">
		     		<a href="#"></a>
		      </div>
		      <div class="slide">
		     		<a href="#"></a>
		      </div>
		       <div class="slide">
		     		<a href="#"></a>
		      </div>
		    </div>
		    <div class="arrow arrow-left"></div>
		    <div class="arrow arrow-right"></div>
		  </div>


		    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

		        <script src="js/index_slide.js"></script>
    		</div>
    		

		<!-- FECHANDO SLIDE -->