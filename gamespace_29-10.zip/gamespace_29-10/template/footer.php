
		
		<!-- ABRINDO FOOTER -->
			<div id="footer">
				<br><br><br><br><br>
			<center><h1>FOOTER<h1></center>
			<br><br><br>
			</div>
		<!-- FECHANDO FOOTER -->
		
		</div>
	<!-- FECHANDO WRAPPER -->
	 <script src="js/fastclick.js"></script>
    <script src="js/scroll.js"></script>
    <script src="js/fixed-responsive-nav.js"></script>
	</body>
<?php
	mysqli_close($con);
?>
</html>