
		<!-- ABRINDO TOPGAMES -->
			<div id="topgames">
				<br>
				<h1 style="font-family: 28px; color#FFF; text-align: center; color: #FFF">TOP GAMES</h1><br></br>
				<h4 style="margin-left: 351px; color: #FFF"></h4>
				<div id="foto"><img src=""></div><br>
				<div id="descricao">
					<p style="color: #FFF"Descrição aqui</p>
				</div>
				
			</div>
		<!-- FECHANDO TOPGAMES -->