		<!-- ABRINDO NAV -->
				<?php 
				
				if(isset($_SESSION['nick']) ){
			
				  	echo '<div class="main-nav">
	  <div class="main-nav__container">
		<div class="main-nav__branding">
		</div>
		<div class="main-nav__inner-nav">
			<a href="index.php">HOME</a>
			<a href="jogos.php">JOGOS</a>
			<a href="#0">CONTATO</a>
			<a href="javascript:void(0)" class="dropdown-trigger--mobile"><i class="material-icons">menu</i></a>
			<a href="#0" class="profile-dropdown-trigger dropdown-trigger">
			<img src="imagens_user/'. $_SESSION['foto'] .'"/></a>
		  <!-- mobile main menu-->



		  <div class="main-nav__dropdown mobile-menu-dropdown">
			<div class="dropdown__nav">
				<a href="index.php"> <span class="material-icons">home</span><span>Home</span></a>
				<a href="jogos.php"><span class="material-icons">videogame_asset</span><span>Jogos</span></a>
				<a href="contato.php"><span class="material-icons">phone</span><span>Contato</span></a>
			</div>
		  </div>
		  <div class="main-nav__dropdown profile-dropdown"><a href="#0" class="dropdown__header"><img src="imagens_user/'. $_SESSION['foto'] .'"/>
			  <h5 class="dropdown__name">'. $_SESSION['nick'] .'</h5><span class="dropdown__title">Jogando</span></a>
			<div class="dropdown__nav"><a href="#0"> <span class="material-icons">chat</span><span>Mensagem</span></a><a href="#0"><span class="material-icons">videogame_asset</span><span>Jogos</span></a><a href=" alterar_user.php?id = '.$_SESSION['id_user'].'"><span class="material-icons">account_box</span><span>Perfil</span></a><a href="logout.php"><span class="material-icons">exit_to_app</span><span>Sair</span></a></div>
		  </div>
		</div>
	  </div>
	</div>';
				  	if($_SESSION['tipo']==0){
				  		 echo '<a href="admin.php"></a>';
				  	}
				  }
				 
				/*  else if(isset($_COOKIE['nick']) ){
				  	  	
						echo '<div class="main-nav">
	  <div class="main-nav__container">
		<div class="main-nav__branding">
		</div>
		<div class="main-nav__inner-nav">
			<a href="index.php">HOME</a>
			<a href="jogos.php">JOGOS</a><a href="#0">CONTATO</a>
			<a href="javascript:void(0)" class="dropdown-trigger--mobile"><i class="material-icons">menu</i></a>
			<a href="#0" class="profile-dropdown-trigger dropdown-trigger">
			<img src="imagens_user/'. $_SESSION['foto'] .'"/></a>
		  <!-- mobile main menu-->



		  <div class="main-nav__dropdown mobile-menu-dropdown">
			<div class="dropdown__nav">
				<a href="index.php"> <span class="material-icons">home</span><span>Home</span></a>
				<a href="jogos.php"><span class="material-icons">videogame_asset</span><span>Jogos</span></a>
				<a href="contato.php"><span class="material-icons">phone</span><span>Contato</span></a>
			</div>
		  </div>
		  <div class="main-nav__dropdown profile-dropdown"><a href="#0" class="dropdown__header"><img src="imagens_user/'. $_SESSION['foto'] .'"/>
			  <h5 class="dropdown__name">'. $_SESSION['nick'] .'</h5><span class="dropdown__title">Front End Dev</span></a>
			<div class="dropdown__nav"><a href="#0"> <span class="material-icons">chat</span><span>Mensagem</span></a><a href="#0"><span class="material-icons">videogame_asset</span><span>Jogos</span></a><a href="#0"><span class="material-icons">account_box</span><span>Perfil</span></a><a href="logout.php"><span class="material-icons">exit_to_app</span><span>Sair</span></a></div>
		  </div>
		</div>
	  </div>
	</div>';
						//$_SESSION["tipo"] = $_COOKIE['tipo'];
				  	if($_SESSION['tipo']==0){
				  		 echo '<a href="admin.php"></a>';
				  	}
				  }
				  */
				  ?>
			
			<?php
				if (!isset($_SESSION['nick'])) {
					//echo '<div class="main-nav">
				//	<form name = "logar" action = "login.php" method = "Post" enctype = "multipart/form-data">';

					include"template/nav_deslogado.php";

					//echo '<input type="submit" class="envio btn" name="Entrar" value= "ENTRAR">
					//</form></div>';
				}
			?>
		<!-- FECHANDO NAV -->
<script src="js/js_mini_perfil_nav.js"></script>