<?php
	include"template/topo.php";
?>	


<div id="content">
				<?php $sql = "select * from jogo;";
					$rs = mysqli_query ($con,$sql);
					while ($valor = mysqli_fetch_array($rs)){ ?>
					<!-- ABRINDO JOGOS -->
					
						<div id="div_jogos">
							<a href="pag_jogo.php?id=<?php echo$valor["id_jogo"]?>">
							<img class = "img_jogos"  src="imagens_jogo/<?php echo $valor['foto']?>" 
							alt="imagens_jogo/noimage.png"><br>
							<h3 class = "nome_jogo" ><?php echo $valor ['nome_jogo']; ?></h3>
							</a>
						</div>
					<!-- FECHANDO JOGOS -->
				<?php }; 
					mysqli_free_result($rs); ?>

<?php
	include"template/footer.php"
?>
</div>
