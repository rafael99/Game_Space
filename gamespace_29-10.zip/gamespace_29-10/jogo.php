<?php
	include"template/topo.php";
	
	if(!isset($_SESSION['nick']) ){
    	if(!isset($_COOKIE['nick'])){
        	echo"<meta http-equiv='refresh' content='0;url=index.php'>";
    	}
	    else{
			
	        $sql = "select * from usuario where nick = ".$_COOKIE['nick'];
	        $rs=mysqli_query($con, $sql);
	        $_SESSION["nick"] = $_COOKIE['nick'];
	        $_SESSION["senha"] =$_COOKIE['nick'];
	        $_SESSION["nome"] = $_COOKIE['nick'];
	    }
	}
?>
			<!-- ABRINDO CONTENT -->
			<div id="contentadmin">
			
			<?php $sql = "select * from jogo;";
				$rs = mysqli_query ($con,$sql);
				while($valor = mysqli_fetch_array($rs)){ 
				?>
				<!-- ABRINDO JOGOS -->
				<div id="jogosadmin">
				 <a href="#myModal<?php echo $valor['id_jogo'] ?>"  data-toggle="modal"><img class="img_jogos" src="imagens_jogo/<?php echo $valor['foto']?>" alt="imagens_jogo/noimage.png" width="120" height="120" align="left"></a><h4><?php echo $valor ['nome_jogo']; ?></h4>
				 <!--MODAL-->
				 
					<div id="myModal<?php echo $valor['id_jogo'] ?>" class="modal fade">
				        <div class="modal-dialog">
				            <div class="modal-content">
				                <div class="modal-header">
				                	<img class="img_jogo" src="imagens_jogo/<?php  echo $valor['foto']?>" align= "left" >
				                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				                    <h4 class="modal-title"><?php echo $valor['nome_jogo']?></h4>
				                    <p class="text-warning"><small>Plataformas: <?php echo $valor['plataforma_jogo']?><br>Gênero: <?php echo $valor['genero_jogo']?><br>Distribuidora: <?php echo $valor['distribuidora_jogo']?></small> </p>
				                    
				                    <p> <?php echo $valor['descricao_jogo']?></p>
				   					<hr><br><br>
				   					<ul class="list-inline btn_modal">
				   						<li><button type="button" id = "add_jogo_modal" class="btn btn-primary">Favotitos</button></li>
				   						<li><button type="button" id = "favoritos_modal" class="btn btn-success">Adicionar Jogo</button></li>
				   					</ul>
				                </div>
				            </div>
				        </div>
				    </div>
				    <!--FIM MODAL-->

				</div>
				<!-- FECHANDO JOGOS -->
			<?php };
				mysqli_free_result($rs);
				 ?>

					
			</div>
			<!-- FECHANDO CONTENT -->
			
			<!-- ABRINDO BOTAO ADD -->
			<div id="botaoadd">
			<form name="incJogo" action="cadastro_jogo.php" method="POST" enctype="multipart/form-data">
				<input type="submit" class="button_adc_jogo" value="ADICIONAR JOGO" >
			</div>
			<!-- FECHANDO BOTAO ADD -->


<?php
	include"template/footer.php"
?>
