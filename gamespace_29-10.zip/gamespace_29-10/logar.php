<?php
	include "conexao/conecta.php";

	session_start();
	include "conexao/conecta.php";
	$nick = $_POST['nick'];
	$senha = sha1($_POST['senha']);
	$sql = "select * from usuario where nick = '$nick'";
	$rs=mysqli_query($con, $sql);
	$linhas= mysqli_num_rows($rs);
	if($linhas==0){
		echo"<meta http-equiv='refresh' content='0;url=senhaIncorreta.php'>";
	}
	else{
		$valor = mysqli_fetch_array($rs);
		if($senha != $valor["senha"]){
			echo"<meta http-equiv='refresh' content='0;url=senhaIncorreta.php'>";
		}

		else if(isset($_POST["conect"])){
			if(!isset($_COOKIE['nick'])){
				setcookie("nick", $nick, time() + (86400*2));
				setcookie("senha", $senha, time() + (86400*2));
				setcookie("nome", $valor["nome"], time() + (86400*2));
				setcookie("tipo", $valor["tipo"], time() + (86400*2));
				setcookie("id_user", $valor["id_user"], time() + (86400*2));
				setcookie("foto", $valor['foto'], time() + (86400*2));
				$_SESSION["nick"] = $nick;
				$_SESSION["senha"] = $senha;
				$_SESSION["tipo"] = $valor["tipo"];
				$_SESSION["nome"] = $valor["nome"];
				$_SESSION["id_user"] = $valor["id_user"];
				$_SESSION["foto"] = $valor["foto"];
				
				echo"<meta http-equiv='refresh' content='0;url=verifica_usuario.php'>";
			}

			for($i = 0; $i < Count($_POST["conect"]); $i++){
				//echo "<br>".$_POST["conect"][$i];
			}
		}

		else if(!isset($_SESSION['id_user'])){
			$_SESSION["nick"] = $nick;
			$_SESSION["senha"] = $senha;
			$_SESSION["tipo"] = $valor["tipo"];
			$_SESSION["nome"] = $valor["nome"];
			$_SESSION["id_user"] = $valor["id_user"];
			$_SESSION["foto"] = $valor["foto"];
			
			echo $_SESSION['nick'];
			echo $_SESSION['tipo'];
			
			echo"<meta http-equiv='refresh' content='0;url=verifica_usuario.php'>";
		
		}
	}

	mysqli_close($con);
?>
