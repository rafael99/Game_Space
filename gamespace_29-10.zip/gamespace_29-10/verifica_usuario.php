<?php

        session_start();
	include "conexao/conecta.php";

	if($_SESSION["tipo"] == 0){
		
		echo"<meta http-equiv='refresh' content='0;url=admin.php'>";
	}else if($_SESSION['tipo'] == 1){
		
		echo"<meta http-equiv='refresh' content='0;url=index.php'>";
	}

?>