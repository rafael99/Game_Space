<?php
	include"template/topo.php";
	include"template/slide.php";
?>
		<!-- ABRINDO CONTENT -->
			<div id="content" >
			<br><br><br><br><br>
			<center><h1 class = "alinha">CONTEÚDO<h1></center>
			<br><br><br><br><br>
		
			</div>
		<!-- FECHANDO CONTENT -->
		
<?php
	include"template/topgames.php";
	include"template/footer.php"
?>