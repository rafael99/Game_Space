<?php
	include"template/topo.php";
	
	if(!isset($_SESSION['nick']) ){
    	if(!isset($_COOKIE['nick'])){
        	echo"<meta http-equiv='refresh' content='0;url=index.php'>";
    	}
	    else{
			
	        $sql = "select * from usuario where nick = ".$_COOKIE['nick'];
	        $rs=mysqli_query($con, $sql);
	        $_SESSION["nick"] = $_COOKIE['nick'];
	        $_SESSION["senha"] =$_COOKIE['nick'];
	        $_SESSION["nome"] = $_COOKIE['nick'];
	    }
	}

	else if($_SESSION["tipo"] == 1){
	    echo"<meta http-equiv='refresh' content='0;url=index.php'>";
	}

?>
			<!-- ABRINDO CONTENT -->
			<div id="contentadmin">
			
			<?php $sql = "select * from jogo;";
				$rs = mysqli_query ($con,$sql);
				while($valor = mysqli_fetch_array($rs)){ ?>
				<!-- ABRINDO JOGOS -->
				<div id="jogosadmin">
				 <img class="jogosadminimg" src="imagens_jogo/<?php echo $valor['foto']?>" alt="imagens_jogo/noimage.png"><h3><?php echo $valor ['nome_jogo']; ?></h3>
				 <a href="altera_jogo.php?id=<?php echo$valor["id_jogo"]?>"><span><img class ="alter" src="imagens/editar.png"></span></a>
				</div>
				<!-- FECHANDO JOGOS -->
			<?php };
				mysqli_free_result($rs); ?>
			</div>
			<!-- FECHANDO CONTENT -->
			
			<!-- ABRINDO BOTAO ADD -->
			<div id="botaoadd">
			<form name="incJogo" action="cadastro_jogo.php" method="POST" enctype="multipart/form-data">
				<input type="submit" class="button_adc_jogo" value="ADICIONAR JOGO" >
			</div>
			<!-- FECHANDO BOTAO ADD -->


<?php
	include"template/footer.php"
?>
