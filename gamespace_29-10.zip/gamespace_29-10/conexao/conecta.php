<?php
	
	$con = mysqli_connect("localhost", "root", "", "admgasp_gamespace")
	or die ("A conexão com o servidor não foi executada com sucesso");

?>