<?php
  include "conexao/conecta.php";
?>

<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>LOGIN - CADASTRO</title>
    <link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/normalize.css">    
    <link rel="stylesheet" href="css/style_login.css">

  </head>
  <body>
    <br><br><br>
   
    <div class="form">
     
        <div id="login">  <!--logar--> 
          
          <h1><font color="red">NICK OU SENHA INCORRETOS!</font></h1>
          
          <form name = "incUser" action = "logar.php" method = "Post" enctype = "multipart/form-data">
               
            <div class="field-wrap">
            <label>
              Nick
            </label>
            <input type="text" name= "nick" required autocomplete="off"/>
          </div>
          
          <div class="field-wrap">
            <label>
              Senha
            </label>
            <input type="password" name = "senha"required autocomplete="off"/>
          </div>
          
          <p class="forgot"><a href="#">Esqueci minha senha</a></p>
          <br>

          <input class = "conecta" type="checkbox" name="conect[]" value = "senha salva" /><span>Mantenha-me conectado</span>
          <button class="button button-block">Entrar</button>

          
          </form>

        </div>
        <br>
        <a href="index.php" class = "voltar" >← VOLTAR</a>
        <a href="cadastro.php" class = "voltar_cadastro" >CADASTRE-SE</a>
      
    </div> <!-- /form -->
        <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
        <script src="js/index_login.js"></script>

  </body>

  <?php
    mysqli_close($con);
  ?>
</html>