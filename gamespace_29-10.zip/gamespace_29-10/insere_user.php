<?php
	include "template/topo.php";
	$nick = $_POST['nick'];
	$senha = sha1($_POST['senha']);
	$email = $_POST['email'];
	
		if ($_FILES["foto"]["error"] == 0){
		$ext = substr($_FILES["foto"]["name"],
			strpos(strrev($_FILES["foto"]["name"]), ".") *-1);
		
		$foto = sha1(time().$_FILES["foto"]["name"]).".".$ext;
		move_uploaded_file($_FILES["foto"]["tmp_name"], "imagens_user/".$foto);
	}else{
		$foto = "nouser.png";
	}
	if($con){
		$sql = "insert into usuario(nick, senha,email,foto)".
			" values('$nick', '$senha','$email','$foto')";
		$rs = mysqli_query($con, $sql);
		if($rs){
			header("login.php");
			echo"<meta http-equiv='refresh' content='0;url=login.php'>";
		}else{
			echo " Erro de inclusão: ".mysqli_error($con);
		}
	}else{
		echo " Erro de conexão: ".mysqli_error($con);
	}
	include "template/footer.php";
?> 