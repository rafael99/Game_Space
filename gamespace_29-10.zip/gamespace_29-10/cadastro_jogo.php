<?php
	include"template/topo.php";
	if(!isset($_SESSION['nick']) ){
    	if(!isset($_COOKIE['nick'])){
        	echo"<meta http-equiv='refresh' content='0;url=index.php'>";
    	}
	    else{
	        $sql = "select * from usuario where nick = ".$_COOKIE['nick'];
	        $rs=mysqli_query($con, $sql);
	        $_SESSION["nick"] = $_COOKIE['nick'];
	        $_SESSION["senha"] =$_COOKIE['nick'];
	        $_SESSION["nome"] = $_COOKIE['nick'];
	    }
	}

	else if($_SESSION["tipo"] == 1){
	    echo"<meta http-equiv='refresh' content='0;url=index.php'>";
	}
?>
<div id="content" >
 <form name="incCliente" action="insere_jogo.php" method="POST" enctype="multipart/form-data"> 
					<div class="box"> 
						<h1 style="margin-left: 100px;">CADASTRO DE JOGO</h1> 

						<label> 
							<span>Nome:</span>
							<input type="text" class="input_text" name="nome_jogo" required maxlength="60" > 
						</label>
						<label> 
							<span>Distribuidora:</span>
							<input type="text" class="input_text" name="distribuidora_jogo" required  maxlength="60" > 
						</label>
						<label> 
							<span>Plataforma:</span>
							<input type="text" class="input_text" name="plataforma_jogo"  required maxlength="50" > 
						</label>
						<label> 
							<span>Gênero:</span>
							<input type="text" class="input_text" name="genero_jogo" required maxlength="30" > 
						</label>
						<label> 
							<span>Descrição:</span>
							<textarea type="text" class="input_text2" required name="descricao_jogo" cols="40" rows="10"></textarea>
						</label>
						<label> 
							<span>Foto:</span>
							<input type="file"  name="foto" > 
						</label>
						<label>
							<p class="button_admin"><a href="admin.php">ADMIN/VOLTAR</a></p>
						</label>
						
</form>
						<label>
							<input type="submit" class="button_cadastro_jogo" value="CADASTRAR" >
						</label>
</div>				
<?php
	include"template/footer.php";
?>