<?php
	include "template/topo.php";
?>
 <div ="content">
<?php
	$id_jogo = $_GET['id'];
	if($con){
		$sql = "select * from jogo where id_jogo = ".$_GET['id'];
		$rs = mysqli_query($con, $sql);
		if($rs){
			if($valor = mysqli_fetch_array($rs)){
				$sql = "delete from jogo where id_jogo = $id_jogo;";
			$rs = mysqli_query($con, $sql);
			if($rs){
				echo "<h1 class='alinha'>Jogo excluido com sucesso.</h1>";
				if($valor["foto"] != "noimage.png"){
					unlink("imagens_jogo/".$valor["foto"]);
				}
				echo"<meta http-equiv='refresh' content='1;url=admin.php'>";
			}
			}
		}else{
			echo " Erro de exclusão: ".mysqli_error($con);
		}
	}else{
		echo " Erro de conexão: ".mysqli_error($con);
	}
?>
 </div>
<?php
	include "template/footer.php";
?>